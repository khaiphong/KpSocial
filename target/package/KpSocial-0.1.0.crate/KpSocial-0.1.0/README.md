# KpSocial

Social works to promote "<b>Core Values of Honesty &amp; Care</b>". <b>GsLp (Global Services Local Presence) / ThankYou Club</b> - a NfP (Not-for-Profit) social place donated and driven by people benefitting from the community supports for their developments and successes - is the starting point to <b>promote local communities to the World and bring global services in economic efficiencies to the local vibrant economy</b>.
