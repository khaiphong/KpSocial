//! # KpSocial
//!
//! A collection of utilities to enable KpSocial happened and efficient.

